<?php
    $a="111";
    if(isset($_POST['a']))
    {
      if($_POST['a']=="first")
      {
        $a=" Вы кодите на C#";
      }
      else if($_POST['a']=="second")
      {
        $a=" Выкодите на JS/PHP/HTML/CS";
      }
      else if($_POST['a']=="tird")
      {
        $a=" Вы кодите на C++";
      }
      else if($_POST['a']=="fourth")
      {
        $a=" Вы не кодер";
      }
    }
    
    echo "<div><p style=\" ;font-size: 400%; text-align: center;\"> $a</p></div>";
    $fp = fopen('tosave.txt', 'a+t'); 
    fwrite($fp, date('Y-m-d H:i:s').$a."\n\r");
    fclose($fp);

?>
</body>