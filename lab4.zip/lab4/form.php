<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        span{font-size: 150%; font-family: monospace;}  
    </style>
</head>
<body >
    <table style= border=1   >
    <tr >
        <th>
            <span>на чем кодишь?<br></span>
        </th>
    </tr>
    <tr>
        <td>
            <form action="Function.php" method="POST" >            
                <input  type="radio"  name="a"  value="first" checked="true"><span>C#</span><br>
                <input  type="radio"  name="a"  value="second" ><span>JS/PHP/HTML/CS</span><br>
                <input  type="radio"  name="a"  value="tird" ><span>C++</span><br>
                <input  type="radio"  name="a"  value="fourth" ><span>я что похож на кодера?</span><br>
                <tr>
                    <td align="center"  >
                    <input id="button" type="submit" name="button2" value="Выбор">
                    </td>
                </tr>              


            </form>
        </td>
    </tr>
    </table>  

</body>
</html>

